local json = require 'cjson.safe'
return
{
    log_dir = '/data/log/devconn',
    log_file = 'devconn.log_%d+.log',
    output_dir = '/opt/log_filter/log',
    filter = {
        ['DeleteDevice'] = function (line)
            return json.encode({time=string.match(line, '^(%d+-%d+-%d+ %d+:%d+:%d+,%d+)'), device_id=string.match(line, 'DeleteDevice : (%w+)'),action='Delete'}) .. '\n'
        end,
        ['AddDevice'] = function (line)
            return json.encode({time=string.match(line, '^(%d+-%d+-%d+ %d+:%d+:%d+,%d+)'), device_id=string.match(line, 'AddDevice : (%w+)'),action='Add'}) .. '\n'
        end
    },
    debug = 0
}
        --[[
        DeleteDevice = function (line)
           return 'DeleteDevice filter ' .. line 
        end ,
        AddDevice = function (line) 
           return 'AddDevice filter ' .. line 
        end
        --]]
