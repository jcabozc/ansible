local inotify = require 'inotify'
local config = require 'config'

local filter = config.filter
local work_dir = config.log_dir
local file_filter = config.log_file
local output_dir = config.output_dir
local debug = config.debug

local file = nil
local fname = nil

local function openfile(fname)
    local fpath =  output_dir .. '/' .. fname
    return io.open(fpath, 'a+')
end

local function write_line(line)
    local cur_date = os.date('%Y-%m-%d.log')

    if file == nil then
        fname = cur_date
        file = openfile(fname)
    end

    if fname ~= cur_date then
        if file then 
            io.close(file) 
            file = nil
        end
        fname = cur_date
        file = openfile(fname)
    end

    if line then
        file:write(line)
        file:flush()
    end
end

local function filter_lines(str)
    local i = 0
    local t = {}
    while true do
        local p = i+1
        i = string.find(str, '\n', i+1)
        if i == nil then break end  
        line = string.sub(str, p, i)
        if line and string.len(line) > 0 then
            for k,v in pairs(filter) do
                if string.match(line, k) then
                    if debug == 1 then
                        io.write(v(line))
                        io.flush()
                    else
                        write_line(v(line))
                    end
                    break
                end
            end
        end
    end
end

local function fdump_bytes(fh, n)
    local str = fh.fd:read(n)
    if str then
        if fh.cache then
            str = fh.cache .. str
            fh.cache = nil
        end
        -- '\n' == 10
        if string.byte(str, -1) == 10 then
            filter_lines(str)
        else
            fh.cache = str
        end
    end
end

--local function sdump_last_lines(str, n)
--    local i = 0
--    local t = {}
--    --local n=3
--    while true do
--        p = i+1
--        i = string.find(str, '\n', i+1)
--        if i == nil then break end  
--        table.insert(t, string.sub(str, p, i)) 
--        --print(i)
--    end
--    for j,v in ipairs(t) do
--        if #t - j < n then
--            io.write(v)
--        end
--    end
--end
--
--local function fdump_last_lines(file, n)
--    local file_size = fsize(file)
--    if file_size == nil then
--        return 0
--    end
--    local sk=4096
--    if file_size < sk then
--        sk = file_size
--    end
--    file:seek("end", -sk)
--    local str = file:read(sk)
--    sdump_last_lines(str, n)
--    return file_size
--end
-- Watch for new files and renames
local function lmain()
    local file_handles = {}
    local handle = inotify.init()
    local wd = handle:addwatch(work_dir, inotify.IN_CREATE, inotify.IN_MOVED_FROM, inotify.IN_MODIFY, inotify.IN_DELETE)

    for ev in handle:events() do
        -- print(ev.name .. ' was created or renamed')
        if string.match(ev.name, file_filter) then
            fpath = work_dir .. '/' .. ev.name
            fh = file_handles[fpath]
            if ev.mask == inotify.IN_MODIFY then
                --print(fpath .. ' modify')
                if fh == nil then
                    fh = {}
                    fh.fd = io.open(fpath, 'r')
                    fh.read_pos = handle:fsize(fpath)
                    fh.fd:seek('end')
                    file_handles[fpath] = fh
                    --fh.read_pos = fdump_last_lines(fh.fd, 10)
                else
                    file_size = handle:fsize(fpath)
                    bytes = file_size - fh.read_pos
                    if bytes > 0 then
                        fh.read_pos = file_size
                        fdump_bytes(fh, bytes)
                    end
                end
            elseif ev.mask == inotify.IN_CREATE then
                if fh == nil then
                    fh = {}
                    fh.fd = io.open(fpath, 'r')
                    fh.read_pos = 0
                    file_handles[fpath] = fh
                end
                --print(fpath .. ' created')
            elseif ev.mask == inotify.IN_MOVED_FROM then
                if fh then
                    io.close(fh.fd)
                    file_handles[fpath] = nil
                end
                --print(fpath .. ' moved_away')
            elseif ev.mask == inotify.IN_DELETE then
                if fh then
                    io.close(fh.fd)
                    file_handles[fpath] = nil
                end
                --print(fpath .. ' deleted')
            end
        end
    end

    handle:rmwatch(wd)
    handle:close()
end

lmain()
